package com.example.smarteyemask;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.content.Context;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    EyeMaskView view;
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(8,17,27)); view=new EyeMaskView(this); setContentView(view); }
}

class EyeMaskView extends View {
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    int page=0; float left=34.0f,right=33.9f,target=40f; int seconds=600; boolean running=false; long lastTick=0;
    Handler h=new Handler(); Random rnd=new Random();
    int bg=Color.rgb(11,23,35), card=Color.rgb(20,38,61), header=Color.rgb(106,169,232), white=Color.rgb(244,247,251), muted=Color.rgb(170,185,204), accent=Color.rgb(105,180,242), green=Color.rgb(32,179,107), red=Color.rgb(240,75,75);
    Typeface rounded=Typeface.create("sans-serif-rounded",Typeface.NORMAL), bold=Typeface.create("sans-serif-rounded",Typeface.BOLD);
    String[] nav={"Home","Timer","Monitor","History","Safety"};
    EyeMaskView(Context c){ super(c); p.setTypeface(rounded); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(2); stroke.setColor(Color.rgb(43,69,98)); setBackgroundColor(bg); h.post(tick); }
    void tick(){ if(running){ long now=System.currentTimeMillis(); if(lastTick>0 && now-lastTick>=1000){ int d=(int)((now-lastTick)/1000); seconds=Math.max(0,seconds-d); left=Math.min(target,left+0.08f); right=Math.min(target,right+0.07f); if(seconds==0) running=false; lastTick=now; } else if(lastTick==0) lastTick=now; invalidate(); } else lastTick=0; h.postDelayed(this::tick,250); }
    void txt(Canvas c,String s,float x,float y,float size,int color,boolean b){ p.setTypeface(b?bold:rounded); p.setTextSize(size); p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawText(s,x,y,p); }
    void center(Canvas c,String s,float x,float y,float size,int color,boolean b){ p.setTypeface(b?bold:rounded); p.setTextSize(size); p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawText(s,x-p.measureText(s)/2,y,p); }
    void round(Canvas c,float l,float t,float r,float b,float rad,int color){ p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawRoundRect(l,t,r,b,rad,rad,p); stroke.setColor(Color.rgb(39,64,92)); c.drawRoundRect(l,t,r,b,rad,rad,stroke); }
    @Override protected void onDraw(Canvas c){ super.onDraw(c); int w=getWidth(),hgt=getHeight();
        // Header
        p.setColor(header); c.drawRect(0,0,w,84,p); txt(c,"Smart Eye Mask",28,54,31,white,false); round(c,w-164,20,w-18,64,24,Color.rgb(123,184,239)); center(c,"Connected",w-91,50,18,white,false);
        int bottom=hgt-72; p.setColor(Color.rgb(20,39,62)); c.drawRect(0,bottom,w,hgt,p); float bw=w/5f; p.setColor(accent); c.drawRect(page*bw,bottom,page*bw+bw,bottom+4,p);
        switch(page){case 0:home(c);break;case 1:timer(c);break;case 2:monitor(c);break;case 3:history(c);break;case 4:safety(c);break;}
        for(int i=0;i<5;i++) center(c,nav[i],bw*i+bw/2,bottom+45,17,i==page?accent:muted,false);
    }
    void card(Canvas c,float l,float t,float r,float b){round(c,l,t,r,b,24,card);}
    void home(Canvas c){ int w=getWidth(); card(c,28,112,w-28,310); txt(c,"Left eye",52,155,18,muted,false); txt(c,String.format(Locale.US,"%.1f°C",left),52,211,42,Color.rgb(247,132,56),true); txt(c,"Right eye",w/2+10,155,18,muted,false); txt(c,String.format(Locale.US,"%.1f°C",right),w/2+10,211,42,Color.rgb(247,132,56),true); center(c,"Time remaining",w/2,252,17,muted,false); center(c,fmt(seconds),w/2,292,48,white,true);
        card(c,28,330,w-28,450); txt(c,"Target temperature",52,370,18,muted,false); center(c,String.format(Locale.US,"%.1f°C",target),w/2,418,40,white,true); button(c,52,386,130,442,"−",accent); button(c,w-130,386,w-52,442,"+",accent);
        button(c,28,474,w/2-10,532,"Start",green); button(c,w/2+10,474,w-28,532,"Stop",red);
    }
    void timer(Canvas c){ int w=getWidth(); card(c,28,112,w-28,285); txt(c,"Session length",52,151,21,muted,false); int[] mins={5,10,15,20}; float bwid=(w-104-36)/4f; for(int i=0;i<4;i++){float x=52+i*(bwid+12),y=190; round(c,x,y,x+bwid,y+64,20,(seconds/60==mins[i])?accent:card); center(c,mins[i]+" min",x+bwid/2,y+39,18,white,false);} card(c,28,310,w-28,528); txt(c,"Selected",52,352,20,muted,false); center(c,fmt(seconds),w/2,435,70,white,true); center(c,"The mask shuts off automatically when time ends.",w/2,480,16,muted,false); button(c,28,548,w/2-10,612,"Start session",green); button(c,w/2+10,548,w-28,612,"Pause",accent); }
    void monitor(Canvas c){ int w=getWidth(); card(c,28,112,w-28,530); txt(c,"Live temperature (last 60 s)",52,158,21,muted,false); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(4); stroke.setColor(Color.rgb(241,116,48)); Path a=new Path(); Path b=new Path(); for(int i=0;i<60;i++){float x=52+i*(w-104)/59f; float base=390-60*(float)Math.sin(i/20.0); if(i>12) base-=Math.min(110,(i-12)*3); float y=base; if(i==0){a.moveTo(x,y);b.moveTo(x,y+3);}else{a.lineTo(x,y+(float)Math.sin(i)*2);b.lineTo(x,y+5+(float)Math.cos(i)*2);}} c.drawPath(a,stroke); stroke.setColor(Color.rgb(40,105,190)); c.drawPath(b,stroke); p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(241,116,48)); c.drawCircle(73,478,7,p); txt(c,"Left",88,485,19,Color.rgb(241,116,48),true); p.setColor(Color.rgb(40,105,190)); c.drawCircle(190,478,7,p); txt(c,"Right",205,485,19,Color.rgb(40,105,190),true); card(c,28,550,w-28,670); txt(c,"Alerts",52,592,21,muted,false); txt(c,"No alerts this session.",52,632,19,white,false); }
    void history(Canvas c){ int w=getWidth(); card(c,28,112,w-28,305); txt(c,"Date",52,166,21,muted,false); txt(c,"Length",w/3f,166,21,muted,false); txt(c,"Avg temp",w*0.62f,166,21,muted,false); stroke.setColor(Color.rgb(48,75,104)); stroke.setStrokeWidth(2); c.drawLine(52,190,w-52,190,stroke); txt(c,"No sessions yet. Finish one to see it here.",52,225,18,white,false); }
    void safety(Canvas c){ int w=getWidth(); card(c,28,112,w-28,465); txt(c,"Safety status",52,157,23,white,true); txt(c,"• Auto shut-off:",52,205,20,white,false); txt(c,"On",190,205,20,green,true); txt(c,"• Hardware thermal cutoff:",52,247,20,white,false); txt(c,"On",282,247,20,green,true); txt(c,"• Mask battery: 82%",52,289,20,white,false); txt(c,"• Temperature limit: 38–43°C",52,331,20,white,false); card(c,28,485,w-28,740); txt(c,"Before you use it",52,530,23,white,true); txt(c,"• Never place the device directly on the",52,580,19,white,false); txt(c,"  eyes while testing.",52,610,19,white,false); txt(c,"• Stop if you feel pain or irritation.",52,650,19,white,false); txt(c,"• This is a prototype, not a clinically",52,690,19,white,false); txt(c,"  validated device.",52,720,19,white,false); }
    void button(Canvas c,float l,float t,float r,float b,String s,int color){ round(c,l,t,r,b,20,color); center(c,s,(l+r)/2,t+(b-t)/2+7,19,white,true); }
    String fmt(int s){return String.format(Locale.US,"%02d:%02d",s/60,s%60);} 
    @Override public boolean onTouchEvent(android.view.MotionEvent e){ if(e.getAction()!=MotionEvent.ACTION_UP)return true; float x=e.getX(),y=e.getY(); int w=getWidth(),h=getHeight(); if(y>h-90){page=Math.max(0,Math.min(4,(int)(x/(w/5f))));invalidate();return true;} if(page==0){ if(y>465&&y<550){ if(x<w/2) {running=true; if(seconds==0)seconds=600;} else running=false; } else if(y>330&&y<455){ if(x<180)target=Math.max(38,target-0.5f); else if(x>w-180)target=Math.min(43,target+0.5f); } } else if(page==1){ if(y>180&&y<264){ float bwid=(w-104-36)/4f; int i=(int)((x-52)/(bwid+12)); if(x>=52&&i>=0&&i<4){ int[] m={300,600,900,1200}; seconds=m[i]; running=false; } } else if(y>540&&y<630){ if(x<w/2)running=true; else running=false; } } invalidate(); return true; }
}
