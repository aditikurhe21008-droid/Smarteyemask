# Smart Eye Mask Android App

A prototype Android app recreated from the supplied reference screens: Home, Timer, Monitor, History and Safety.

## Included
- Dark blue UI with rounded cards and bottom navigation matching the references.
- Home: left/right temperature, target temperature, countdown, Start/Stop.
- Timer: 5/10/15/20 minute presets, start/pause and auto countdown.
- Monitor: live-style left/right temperature graph and alerts area.
- History: session table placeholder.
- Safety: auto shut-off, hardware cutoff, battery and safe temperature range.
- Prototype BLE permissions are included for future ESP32/Bluetooth integration.

## Build
Open this folder in Android Studio and let Gradle sync. Then choose **Build > Build APK(s)**.

The generated debug APK will be at:
`app/build/outputs/apk/debug/app-debug.apk`

This is a UI/prototype app. It does not yet communicate with the physical mask or ESP32; temperature values are simulated locally.
